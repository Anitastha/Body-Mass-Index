package com.example.body_mass_index;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText eHeight, eWeight;
    private TextView tResult;
    private Button btnCalculate;
    private Double height, weight, result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eHeight = findViewById(R.id.editHeight);
        eWeight = findViewById(R.id.editWeight);
        tResult = findViewById(R.id.textResult);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnCalculate:
                if (Validation() == true) {
                    height = Double.parseDouble(eHeight.getText().toString());
                    weight = Double.parseDouble(eWeight.getText().toString());
                    height = height * 0.01;
                    BMICalculate call = new BMICalculate();
                    call.setHeight(height);
                    call.setWeight(weight);
                    result = call.CalculateBIM();
                    tResult.setText(Double.toString(call.CalculateBIM()));

                    if (result <= 18.5) {
                        Toast.makeText(this, "Under Weight", Toast.LENGTH_LONG).show();
                    } else if (result <= 18.5 || result <= 24.5) {
                        Toast.makeText(this, "Normal Weight", Toast.LENGTH_LONG).show();
                    } else if (result <= 24.5 || result <= 29.9) {
                        Toast.makeText(this, "Over Weight", Toast.LENGTH_LONG).show();
                    } else if (result > 30) {
                        Toast.makeText(this, "Obesity", Toast.LENGTH_LONG).show();
                    } } }
    }
    public Boolean Validation() {

        if (TextUtils.isEmpty(eHeight.getText())) {

            eHeight.requestFocus();
            eHeight.setError("Please Enter Height");
            return false;
        } else if (TextUtils.isEmpty(eWeight.getText())) {

            eWeight.requestFocus();
            eWeight.setError("Please Enter Weight");
            return false;
        }
        return true;
    }}
